# OnionShare


![Screen 1](/readme-assets/s1.jpg "Screen 1")

Screen 1: Shows the splash screen with the spinner, where our apps connects to TOR network

![Screen 2](/readme-assets/s2.jpg "Screen 2")

Screen 2: Shows the data fetched over the TOR network (shows connectivity) 

![Screen 3](/readme-assets/s3.jpg "Screen 3")

Screen 3: Shows the URL of our apps server over the TOR network in the Upload Fragment with working copy button

![Screen 4](/readme-assets/s4.jpg "Screen 4")

Screen 4: Shows our Download Fragment with a working paste button

